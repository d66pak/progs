package learn.deepak.java;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

/**
 * Hello world!
 * 
 */
public class App {
    public static void main(String[] args) {
        System.out.println("Hello REST Jersey Client!");

        Client client = Client.create();
        WebResource webResource = client
                .resource("http://localhost:8080/rg/AccessMailRegister");
        ClientResponse response = webResource.accept("text/plain").get(
                ClientResponse.class);
        if (response.getStatus() != 200) {

            System.out.println("Failed! HTTP status: " + response.getStatus());
        }
        System.out.println("Response: " + response.getEntity(String.class));
    }
}
