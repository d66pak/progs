#!/home/y/bin/php

<?php

        $CurlHandle = curl_init();
        #curl_setopt($CurlHandle, CURLOPT_URL,           "https://cl01-zms01.lab.isis.frontiernet.net:7071/service/admin/soap");
        curl_setopt($CurlHandle, CURLOPT_URL,           "https://z-mstore.glb.frontiernet.net:7071/service/admin/soap");
        curl_setopt($CurlHandle, CURLOPT_POST,           TRUE);
        curl_setopt($CurlHandle, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($CurlHandle, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($CurlHandle, CURLOPT_SSL_VERIFYHOST, FALSE);

        // ------ Send the zimbraAdmin AuthRequest -----
$AdminUserName = "api_ymig@frontier.com";
$AdminPassword = "AW3b4Pp0aJVcEX4x";

        $SOAPMessage  = '<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope">
                                <soap:Header>
                                        <context xmlns="urn:zimbra"/>
                                </soap:Header>
                                <soap:Body>
                                        <AuthRequest xmlns="urn:zimbraAdmin">
                                                <name>' . $AdminUserName . '</name>
                                                <password>' . $AdminPassword . '</password>
                                        </AuthRequest>
                                </soap:Body>
                        </soap:Envelope>';

        curl_setopt($CurlHandle, CURLOPT_POSTFIELDS, $SOAPMessage);

        if(!($ZimbraSOAPResponse = curl_exec($CurlHandle)))
        {
                print("ERROR: curl_exec - (" . curl_errno($CurlHandle) . ") " . curl_error($CurlHandle));
                return(FALSE);
        }

        // print("Raw Zimbra SOAP Response:<BR>" . htmlentities($ZimbraSOAPResponse) . "<BR><BR>\n");

        // Parse for the sessionId
        // <sessionId type="admin" id="123">123</sessionId>
        $sessionId = strstr($ZimbraSOAPResponse, "<sessionId");
        $sessionId = strstr($sessionId, ">");
        $sessionId = substr($sessionId, 1, strpos($sessionId, "<") - 1);
        // print("sessionId = $sessionId<BR>\n");

        // Parse for the authToken
        // <authToken>123</authToken>
        $authToken = strstr($ZimbraSOAPResponse, "<authToken");
        $authToken = strstr($authToken, ">");
        $authToken = substr($authToken, 1, strpos($authToken, "<") - 1);
        //print("authToken = $authToken<BR>\n");


        // Send zimbraAdmin Delegate Auth Token request
	//$userName = "yahoo_5@lab.isis.frontiernet.net";
	//$userName = "yqa_ftr_1034@frontiernet.net";
	$userName = $argv[1];

        $SOAPMessage = '<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope">
                                <soap:Header>
                                        <context xmlns="urn:zimbra">
                                                <authToken>' . $authToken . '</authToken>
                                        </context>
                                </soap:Header>
                                <soap:Body>
                                        <DelegateAuthRequest xmlns="urn:zimbraAdmin">
                                                <account by="name">' . $userName . '</account>
                                        </DelegateAuthRequest>
                                </soap:Body>
                        </soap:Envelope>';
        //print ("SOAP Message= $SOAPMessage\n");
        curl_setopt($CurlHandle, CURLOPT_POSTFIELDS, $SOAPMessage);

        if(!($ZimbraDelAuthResponse = curl_exec($CurlHandle)))
        {
                print("ERROR: curl_exec - (" . curl_errno($CurlHandle) . ") " . curl_error($CurlHandle));
        }
        // Parse for the dAuthToken
        //print ("DelAuthResponse=$ZimbraDelAuthResponse\n");
        $dAuthToken = strstr($ZimbraDelAuthResponse, "<authToken");
        $dAuthToken = strstr($dAuthToken, ">");
        $dAuthToken = substr($dAuthToken, 1, strpos($dAuthToken, "<") - 1);
        //print("dAuthToken = $dAuthToken<BR>\n");

        #curl_setopt($CurlHandle, CURLOPT_URL, "http://webmail-lab.vip.frontiernet.net/service/soap");
        curl_setopt($CurlHandle, CURLOPT_URL, "http://webmail.frontier.com/service/soap");

        // ------ Send the zimbraMail FolderRequest -----

        $SOAPMessage  = '<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope">
                                <soap:Header>
                                        <context xmlns="urn:zimbra">
                                                <authToken>' . $dAuthToken . '</authToken>
                                        </context>
                                </soap:Header>
                                <soap:Body>
                                        <GetFolderRequest xmlns="urn:zimbraMail"/>
                                </soap:Body>
                        </soap:Envelope>';

        //print ("SOAP Message for Folder Request = $SOAPMessage\n");
        curl_setopt($CurlHandle, CURLOPT_POSTFIELDS, $SOAPMessage);

        if(!($ZimbraSOAPResponse = curl_exec($CurlHandle)))
        {
                print("ERROR: curl_exec - (" . curl_errno($CurlHandle) . ") " . curl_error($CurlHandle));
        }
        //print ("folderResponse: $ZimbraSOAPResponse<BR>\n");
        $folder = $ZimbraSOAPResponse;
        //$folder = preg_replace('/[^(\x20-\x7F)]*/','', $folder);
        //print "\n$folder\n";
        
	// ------ Send the zimbraMail ContactsRequest -----

        $SOAPMessage  = '<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope">
                                <soap:Header>
                                        <context xmlns="urn:zimbra">
                                                <authToken>' . $dAuthToken . '</authToken>
                                        </context>
                                </soap:Header>
                                <soap:Body>
                                        <GetContactsRequest xmlns="urn:zimbraMail"/>
                                </soap:Body>
                        </soap:Envelope>';

        //print ("SOAP Message for Folder Request = $SOAPMessage\n");
        curl_setopt($CurlHandle, CURLOPT_POSTFIELDS, $SOAPMessage);

        if(!($ZimbraSOAPResponse = curl_exec($CurlHandle)))
        {
                print("ERROR: curl_exec - (" . curl_errno($CurlHandle) . ") " . curl_error($CurlHandle));
        }
        //print ("ContactResponse: $ZimbraSOAPResponse<BR>\n");
        $contact = $ZimbraSOAPResponse;
        //$contact = preg_replace('/[^(\x20-\x7F)]*/','', $contact);
        //print "\n$contact\n";
    $startTag = '<ContactData>';
    $endTag = '</ContactData>';
    $data = $startTag.$folder.$contact.$endTag;
    preg_replace("/\n\n+/s","\n",$data);
    print "$data";

?>


