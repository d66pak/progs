#!/usr/local/bin/python
import os
import re
import sys

class contacts:
    def __init__(self,item):
        self.item = item
        self.cwd = "./contactResults"
        if os.path.exists(self.cwd):
            for x in os.listdir(self.cwd):
                fullpath = os.path.join(self.cwd,x)
                if os.path.isfile(fullpath):
                    os.remove(fullpath)
        else:
            os.mkdir(self.cwd)
    
    def contactResults(self):
        if not os.path.isfile(self.item):
            result,fCount,yCount = self.contactCheck(self.item)
            print self.item+" "+result+" "+"fCount="+fCount+" "+"yCount="+yCount
        else:
            contactPass = open(os.path.join(self.cwd,"contactPass.txt"),"a")
            contactFail = open(os.path.join(self.cwd,"contactFail.txt"),"a")
            contactDups = open(os.path.join(self.cwd,"contactDups.txt"),"a")
            contact500 = open(os.path.join(self.cwd,"contact500.txt"),"a")
            contactGuid = open(os.path.join(self.cwd,"contactGuid.txt"),"a")
            contactFront = open(os.path.join(self.cwd,"contactFront.txt"),"a")
            for id in open(self.item,'r'):
                id = id.strip()
                print id 
                result,fCount,yCount = self.contactCheck(id)
		print result,fCount,yCount
                if "guid" in result:
                    contactGuid.write(id+" "+result+" "+"fCount="+fCount+" "+"yCount="+yCount+"\n")
                elif "fetching Frotier" in result:
                    contactFront.write(id+" "+result+" "+"fCount="+fCount+" "+"yCount="+yCount+"\n")
                elif "fetching yahoo" in result:
                    contact500.write(id+" "+result+" "+"fCount="+fCount+" "+"yCount="+yCount+"\n")
                elif int(yCount) >= (int(fCount)-10) and int(yCount) <= int(fCount):
                    if int(fCount) !=0 and int(yCount)==0:
                        contactFail.write(id+" FAIL "+"fCount="+fCount+" "+"yCount="+yCount+"\n")
                    else:
                        contactPass.write(id+" "+result+" "+"fCount="+fCount+" "+"yCount="+yCount+"\n")
                elif int(yCount) >= (int(fCount)-10) and int(yCount) > int(fCount):
                    contactDups.write(id+" pass but more contacts on yahoo side "+"fCount="+fCount+" "+"yCount="+yCount+"\n")
                else:
                    contactFail.write(id+" FAIL "+"fCount="+fCount+" "+"yCount="+yCount+"\n")
            contactPass.close()
            contactFail.close()
            contactDups.close()
            contact500.close()
            contactGuid.close()
            contactFront.close()

    def contactCheck(self,id):
        id = id
        result = "pass"
        try:
            ud = os.popen("udb-test -Rk mbr_guid "+id).read()
            guid = re.search("=.*GUID\x02(.*)",ud).group(1)
        except Exception, e:
            return "missing guid","",""
        f = open("kbfile","w")
        f.write(id+" "+guid)
        f.close()    
        try:
            z = os.popen('./getContacts.php '+id+' | grep -o "<cn" | wc -l').read()
            fCount = z.strip()
        except Exception, e:
            result = "Some issue fetching Frotier contact"
            fCount = '0'
        try:
            x = os.popen("sudo ./pcore_prod_getYahooContact kbfile -np").read()
            yCount = re.search("count\"\:(.*?)\,",x).group(1)
        except Exception, e:
            result = "some issue fetching yahoo contact"
            yCount = '0'
        return result,fCount,yCount

if __name__=='__main__':
    item = sys.argv[1]
    s = contacts(item)
    s.contactResults()
